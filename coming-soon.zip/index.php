<!DOCTYPE html>
<html>
	<head>
		<!-- Basic -->
		<meta charset="utf-8">
		<title>Hello World Corp | Top IT Company in Nepal</title>		
		<meta name="keywords" content="Hello World Corp | Top IT Company in Nepal" />
		<meta name="description" content="Hello World Corp | Top IT Company in Nepal">
		<meta name="author" content="Hello World Corp.">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800%7CShadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="vendor/bootstrap/bootstrap.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.min.css" media="screen">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.theme.default.min.css" media="screen">
		<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" media="screen">

		<!-- Theme CSS -->
		<link rel="stylesheet" href="css/theme.css">
		<link rel="stylesheet" href="css/theme-elements.css">
		<link rel="stylesheet" href="css/theme-blog.css">
		<link rel="stylesheet" href="css/theme-shop.css">
		<link rel="stylesheet" href="css/theme-animate.css">

		<!-- Current Page CSS -->
		<link rel="stylesheet" href="vendor/rs-plugin/css/settings.css" media="screen">
		<link rel="stylesheet" href="vendor/circle-flip-slideshow/css/component.css" media="screen">

		<!-- Skin CSS -->
		<link rel="stylesheet" href="css/skins/default.css">

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="css/custom.css">

		<!-- Head Libs -->
		<script src="vendor/modernizr/modernizr.js"></script>

		<!--[if IE]>
			<link rel="stylesheet" href="css/ie.css">
		<![endif]-->

		<!--[if lte IE 8]>
			<script src="vendor/respond/respond.js"></script>
			<script src="vendor/excanvas/excanvas.js"></script>
		<![endif]-->

	</head>
	<body>

		<div class="body coming-soon">
			<header id="header" class="clean-top" data-plugin-options='{"stickyEnabled": false}'>
				<div class="header-top">
					<div class="container">
						<p><i class="fa fa-laptop"></i><a href="http://monitor.helloworldcorp.biz/">Monitor Login</a> <i class="fa fa-user"></i><a href="http://login.helloworldcorp.biz/">Client Login</a>
						</p>
						<ul class="social-icons">
							<li class="facebook"><a href="https://www.facebook.com/helloworldcorpofficial" target="_blank" title="Facebook">Facebook</a></li>

							<li class="twitter"><a href="https://twitter.com/helloworldcorp5" target="_blank" title="Twitter">Twitter</a></li>

							<li class="instagram"><a href="https://www.instagram.com/helloworldcorp/" target="_blank" title="instagram">Instagram</a></li>

							<li class="linkedin"><a href="https://www.linkedin.com/company/hello-world-corp." target="_blank" title="Linkedin">Linkedin</a></li>
						</ul>
					</div>
				</div>
			</header>

			<div role="main" class="main">
				<div class="container">
					<div class="row">
						<div class="col-md-12 center">
							<div class="logo">
								<a href="./">
									<img width="111" height="54" src="img/logo-default.png" alt="Porto">
								</a>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<hr class="tall">
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 center">
							<h1 class="short small">OUR WEBSITE IS COMING SOON</h1>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<hr class="tall">
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3">
							<div class="progress-bars">
								<div class="progress-label">
									<span><strong>Conception:</strong> Finished</span>
								</div>
								<div class="progress">
									<div class="progress-bar progress-bar-primary" data-appear-progress-animation="100%">
										<span class="progress-bar-tooltip">100%</span>
									</div>
								</div>
								<div class="progress-label">
									<span><strong>Design</strong></span>
								</div>
								<div class="progress">
									<div class="progress-bar progress-bar-primary" data-appear-progress-animation="75%" data-appear-animation-delay="300">
										<span class="progress-bar-tooltip">75%</span>
									</div>
								</div>
								<div class="progress-label">
									<span><strong>Development</strong></span>
								</div>
								<div class="progress">
									<div class="progress-bar progress-bar-primary" data-appear-progress-animation="50%" data-appear-animation-delay="600">
										<span class="progress-bar-tooltip">50%</span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<hr class="tall">
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3">
							<div class="newsletter">
								<h5>Let me know when the site is done</h5>

								<div class="alert alert-success hidden" id="newsletterSuccess">
									<strong>Success!</strong> You've been added to our email list.
								</div>

								<div class="alert alert-danger hidden" id="newsletterError"></div>

								<form action="" method="post">
									<div class="input-group">
										
										<input class="form-control" placeholder="Email Address" name="email" id="email" type="email" required="">
										<span class="input-group-btn">
											<button class="btn btn-default" type="submit" name="subscribe">Subscribe Now</button>
										</span>

									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>

			<footer class="short" id="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-9">
							<h4>About Hello World Corp</h4>
							<p>Hello World Corp is result of five minds combination. We all are from same university and we decided to work for quality and change we want to grow IT industry in Nepal with diffrent concept technology is not short as hear we can create and develop our thoughts so we IT passionate bring the concept lets code <>HelloWorld<> </p>
						</div>
						<div class="col-md-3">
							<h5 class="short">Contact Us</h5>
							<span class="phone">+977 - 01 - 4468092</span>
							<ul class="list icons list-unstyled">
								<li><i class="fa fa-envelope"></i> <strong>Email:</strong> <a href="mailto:info@helloworldcorp.com.np">info@helloworldcorp.com.np</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="footer-copyright">
					<div class="container">
						<div class="row">
							<div class="col-md-1">
								<a href="./" class="logo">
									<img alt="Porto Website Template" class="img-responsive" src="img/logo-footer.png">
								</a>
							</div>
							<div class="col-md-11">
								<p>© Copyright 2017. All Rights Reserved.</p>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>

		<!-- Vendor -->
		<script src="vendor/jquery/jquery.js"></script>
		<script src="vendor/jquery.appear/jquery.appear.js"></script>
		<script src="vendor/jquery.easing/jquery.easing.js"></script>
		<script src="vendor/jquery-cookie/jquery-cookie.js"></script>
		<script src="vendor/bootstrap/bootstrap.js"></script>
		<script src="vendor/common/common.js"></script>
		<script src="vendor/jquery.validation/jquery.validation.js"></script>
		<script src="vendor/jquery.stellar/jquery.stellar.js"></script>
		<script src="vendor/jquery.easy-pie-chart/jquery.easy-pie-chart.js"></script>
		<script src="vendor/jquery.gmap/jquery.gmap.js"></script>
		<script src="vendor/isotope/jquery.isotope.js"></script>
		<script src="vendor/owlcarousel/owl.carousel.js"></script>
		<script src="vendor/jflickrfeed/jflickrfeed.js"></script>
		<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
		<script src="vendor/vide/vide.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="js/theme.js"></script>
		
		<!-- Specific Page Vendor and Views -->
		<script src="vendor/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
		<script src="vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
		<script src="vendor/circle-flip-slideshow/js/jquery.flipshow.js"></script>
		<script src="js/views/view.home.js"></script>
		
		<!-- Theme Custom -->
		<script src="js/custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="js/theme.init.js"></script>

		<!-- Google Analytics: Change UA-XXXXX-X to be your site's ID. Go to http://www.google.com/analytics/ for more information.
		<script type="text/javascript">
		
			var _gaq = _gaq || [];
			_gaq.push(['_setAccount', 'UA-12345678-1']);
			_gaq.push(['_trackPageview']);
		
			(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
			})();
		
		</script>
		 -->

	</body>
</html>
