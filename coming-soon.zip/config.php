<?php

$con = mysql_connect("localhost", "root", "");

if (!$con)
{
	die("error in database connection");
}

$db = mysql_select_db ("biz");

if (!$db)
{
	die("error in database selection");
}
mysql_query("SET NAMES 'utf8'");
?>